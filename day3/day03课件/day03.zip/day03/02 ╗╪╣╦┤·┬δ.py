s = 'aaa'
