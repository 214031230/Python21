host = "127.0.0.1"
port = 3306
database = "test"
user = "root"
password = "@@spf"
charset = "utf8"
logdir = "../logs/info.log"
