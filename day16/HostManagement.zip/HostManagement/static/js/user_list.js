$(function () {
    $(".delete").click(function () {
        $(".mbtn").removeClass("hide")
    })
});