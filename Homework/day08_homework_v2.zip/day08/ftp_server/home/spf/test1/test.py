#!/usr/bin/env python3
lst = ["a","b","c"]
s = "".join(lst)
print(s)