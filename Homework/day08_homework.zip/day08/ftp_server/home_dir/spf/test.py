#!/usr/bin/env python3
a = "1  2 3"
a = a.split(" ",1)
print(a)