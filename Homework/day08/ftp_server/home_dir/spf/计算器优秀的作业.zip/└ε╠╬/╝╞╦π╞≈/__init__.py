#!/usr/local/python3/bin/python3  
#-*- coding:utf-8 -*-
#Filename: __init__.py.py
#Author  : litao
#Python  : 3.6
#Time    : 2018/5/7 15:12
#Version : 1