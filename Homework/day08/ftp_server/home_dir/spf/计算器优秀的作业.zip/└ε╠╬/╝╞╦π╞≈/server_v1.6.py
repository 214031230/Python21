import re

math=lambda x,sign,y:str({'*':float(x)*float(y),'/':float(x)/float(y),'+':float(x)+float(y)}.get(sign))
check=lambda express:express.replace('++','+').replace('+-+-','+').replace('--','+').replace('*+','*').replace('/+','/')
mul_div_re = re.compile(r'(?P<x>-?\d+(\.\d+)?){1}(?P<sign>[/*]){1}(?P<y>-?\d+(\.\d+)?){1}')                 # 乘除的正则
add_sub_re = re.compile(r'(?P<x>-?\d+(\.\d+)?){1}(?P<sign>[+\-]){1}(?P<y>-?\d+(\.\d+)?){1}')                # 加减的正则

def compute(SimExpr):
    formula=mul_div_re.search(SimExpr) if mul_div_re.search(SimExpr) else add_sub_re.search(SimExpr)        # 找第一个乘除或加减
    if formula:
        x,sign,y=formula.group('x', 'sign', 'y')
        SimExpr=SimExpr.replace(x+sign+y,math(x,sign,y),1)
        return compute(check(SimExpr))                                                                       # 如果一个无括号的短式子里有多个乘除或加减，进行递归运算。
    return check(SimExpr)                                                                                    # 没有乘除或加减直接返回短式子。

def main(express):
    has_warp=re.findall(r'\([^()]+\)', express)                                                              # 找到括号最里面的式子。
    if has_warp:
        result=map(compute,[Expr.strip('()') for Expr in has_warp])                                          # 用map返回最里面的式子的值。
        for a,b in zip(has_warp,result):express=check(express.replace(a,b))                                  # 用值替换括号最里面的式子。
        return main(check(express))                                                                          # 递归循环这个过程，直到没有括号。
    else:
        return compute(check(express))                                                                       # 如果没有括号直接，运算。

while True:
    express = input('>>> ').strip().replace(' ', '').replace('-','+-')
    if express=='exit':break
    print(main(express).lstrip('+'))