import re

print('1 - 2 * ( (60-30 +(-40/5) * (9-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 )) - (-4*3)/ (16-3*2) )\n输入 exit 退出')


def compute(SimExpr):
    mul_div_re = re.compile(r'(?P<x>-??\d+(\.\d+)?){1}(?P<sign>[/*]){1}(?P<y>-??\d+(\.\d+)?){1}')
    add_sub_re = re.compile(r'(?P<x>-??\d+(\.\d+)?){1}(?P<sign>[+\-]){1}(?P<y>-??\d+(\.\d+)?){1}')
    def MulDiv(SimExpr):
        mul_div = mul_div_re.search(SimExpr)
        if mul_div:
            x,sign,y = mul_div.group('x', 'sign', 'y')
            if sign == '*':
                SimExpr = re.sub(x + '\*' + y, str(float(x) * float(y)), SimExpr, count=1)
            elif sign == '/':
                SimExpr = re.sub(x + sign + y, str(float(x) / float(y)), SimExpr, count=1)
            return MulDiv(SimExpr)
        return SimExpr
    def AddSub(SimExpr):
        add_sub = add_sub_re.search(SimExpr)
        if add_sub:
            x, sign, y = add_sub.group('x', 'sign', 'y')
            if sign == '+':
                SimExpr = re.sub(x + '\+' + y, str(float(x) + float(y)), SimExpr, count=1)
            return AddSub(SimExpr)
        return SimExpr
    return AddSub(MulDiv(SimExpr))

def main(express):
    has_warp=re.findall(r'\([^()]+\)', express)
    if has_warp:
        result=map(compute,[Expr.strip('()') for Expr in has_warp])
        for a,b in zip(has_warp,result):
            express=express.replace(a,b).replace('++','+').replace('+-+-','+').replace('--','+')
        return main(express)
    else:
        return compute(express.replace('*+','*'))

while True:
    express = input('>>> ').strip().replace(' ', '').replace('-','+-')
    if express=='exit':

        print(main(express).lstrip('+'))
        break
    elif '/0' in express:
        print('不能为0')
