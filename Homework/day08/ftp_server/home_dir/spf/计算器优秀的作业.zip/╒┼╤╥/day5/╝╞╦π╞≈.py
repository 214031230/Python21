import re
bra = re.compile(r'(\([^()]+\))')#获取括号最小括号及内部数据正则表达式
mul = re.compile(r'(\d+\.?\d*\*-\d+\.?\d*)|(\d+\.?\d*\*\d+\.?\d*)')#获取乘法及内部数据正则表达式
div = re.compile(r'(\d+\.?\d*\/-\d+\.?\d*)|(\d+\.?\d*\/\d+\.?\d*)')#获取乘法及内部数据正则表达式
add = re.compile(r'(-?\d+\.?\d*\+-\d+\.?\d*)|(-?\d+\.?\d*\+\d+\.?\d*)')#获取加法及内部数据正则表达式
sub = re.compile(r'(-?\d+\.?\d*\--\d+\.?\d*)|(-?\d+\.?\d*\-\d+\.?\d*)')#获取加法及内部数据正则表达式
c_f = re.compile(r'\(?\-?\+?\d+\)?')#判断下括号中是否还有未计算的数，即满足c_f就没有未计算的数，比如（22），（-32.3）等
strip = re.compile(r'[^(].*[^)]')#脱掉括号
def Add(a):
    aa = re.split(r'\+', add.search(a).group())
    return a.replace(add.search(a).group(),str(float(aa[0]) + float(aa[1])))
def Sub(a):
    e = sub.search(a).group()#-3-3
    if e.startswith('-'):
        e = e.replace('-','+')
        res = Add(e).replace('+','-')
    else:
        e = re.split('-',e)
        res = str(float(e[0])-float(e[1]))
    return a.replace(sub.search(a).group(),res)
def Mul(a):# 3+  5 -3*-0.2-3.3*2.2 -8.5/ 2.4 (每次计算一个)
    aa = re.split(r'\*', mul.search(a).group())
    return a.replace(mul.search(a).group(),str(float(aa[0]) * float(aa[1])))
def Div(a):
    aa = re.split(r'\/', div.search(a).group())
    return a.replace(div.search(a).group(), str(float(aa[0]) / float(aa[1])))
def cal():#计算
    while True:
        var = input('Please input the expression(q for quit):').strip() # 例：express = '1 - 2 * ( (60-30 +(-40/5) * (9-2*5/3 + 7 /3*99/4*2998 +10 * 568/14 )) - (-4*3)/ (16-3*2) )'
        if var == 'q':
            break
        else:
            var = ''.join(var.split())
            var = str('(%s)' % var)  #将最外成加（）,下面循环计算括号内的值
            while bra.search(var) :
            #优先计算除法、乘法、减法、加法：
                var = var.replace('--', '+')  # 检查表达式，并将--运算替换为+运算
                s = bra.search(var).group()  # 将最内层括号及其内容赋给变量s，然后处理最内存括号的数据，处理顺序，除乘减加
                if div.search(s):
                    var = var.replace(s,Div(s))
                elif mul.search(s):
                    var = var.replace(s,Mul(s))
                elif sub.search(s):
                    var = var.replace(s,Sub(s))
                elif add.search(s):
                    var = var.replace(s,Add(s))
                elif c_f.search(s):
                    var = var.replace(s,strip.search(s).group())

        print('result: %.10f' % (float(var)))
cal()