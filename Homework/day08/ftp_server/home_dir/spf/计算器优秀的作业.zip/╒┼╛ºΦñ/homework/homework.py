"""
需求：实现简单的计算器
实现：封装Calculator类， main函数接收input字符串并执行计算
"""

import re
import numpy as np

class Calculator(object):
    """
        1.dict:
            - 运算符和相应函数的字典，实现对应关系，方便调用。[备注:所有的np.方法都可以用lambda x, y: x * y实现。]
        2.cutString:
            - 调用replace，对类似"1-2*-1377723.12637"和类似"1--23*-+-67/-234-/7-2"的多运算符粘在一起字符串进行格式清洗[递归处理]
            - 按优先级先处理括号内的子表达式，将计算结果替换该括号；用re.sub(regex, repl, string)来实现。这里回调了calculate函数
        3.calculate:
            - 调用split，该函数按指定的加减规则或乘除规则切割字符串，返回切割后的数字字符串列表和运算符字符串列表
            - 调用controller
                - 根据判断条件执行计算，此处可以添加计算器的Bug处理
                - 调用dict和__npfunc, 以运算符对应的函数对数字字符串列表进行迭代计算，返回计算结果[类似functools.reduce]
            - 做两步计算:
                - 先按加减切割(split)，得到数字字符串列表和加减运算符列表
                - 遍历加减数字字符串列表，对每一个数字字符串按乘除切割(split)，调用controller执行判断和计算，返回计算结果
                - 将乘除数字字符串计算后值生成列表，替换加减切割的数字字符串列表
                - 执行加减运算并返回计算结果，回传给cutString
        4.loop:
            - 递归执行cutString，没有括号时直接调用calculate并返回最终计算结果
    """

    def __init__(self):
        self.dict = {
            "*": np.multiply,
            "-": np.subtract,
            "+": lambda x, y: x + y,  # np.sum调用的是内置的sum函数，而sum函数接受的是list...
            "/": np.divide,
            "**": np.power,
            "//": np.floor_divide,
        }

    def cutString(self, string):
        """接收字符串，以()匹配"()"并进行分组，对每个分组直接用re.sub执行回调函数(repl)并依据返回值进行依次替换"""
        string_new = self.replace(string)
        return re.sub("(\([^()]+\))", lambda x: self.calculate(x.group().strip("()")), string_new)

    def calculate(self, bracket):  # 直觉感觉这里可以递归，毕竟类似三级菜单
        """对匹配到的()内的表达式先进行加减切割，再进行乘除切割，先计算乘除，计算结果组成列表替换到加减字符串里，再计算加减，返回加减的计算值"""
        sum_sub_string, sum_sub_symbol = self.split("[\+\-]{1,2}", bracket)
        sum_sub_calculate = [self.controller(*self.split("[\*\/]{1,2}", string)) for string in sum_sub_string]
        return self.controller(sum_sub_calculate, sum_sub_symbol)

    def split(self, regex, string):
        """按指定的表达式("[\+\-]"或"[\*\/]")切割字符串，各自生成列表"""
        number_list = [sub for sub in re.split(regex, string) if sub != ""]  # 这里要过滤掉单个数值字符，交给后面的函数执行判断和返回值即可
        symbol_list = re.findall(regex, string)
        return number_list, symbol_list

    def controller(self, number_list, symbol_list):
        """Bug处理器: 接收split函数切割后的两个列表，并根据两个列表的长度添加判断条件和调用计算函数"""
        if len(number_list) > 1:
            if len(number_list) > len(symbol_list):  # 数字列表一定比运算符列表长，否则只会出现一种情况，开头带符号
                value = self.__npfunc(number_list, symbol_list)
            else:
                number_list[0] = symbol_list[0] + number_list[0]  # 假如运算符列表长度等于数字字符串长度，那么第一个符号一定是第一个数字的前缀符号
                value = self.__npfunc(number_list, symbol_list[1:])
        else:
            if len(number_list) == len(symbol_list):
                value = "-" + number_list[0]
            else:
                value = number_list[0]
        return value

    def replace(self, string):
        """递归替换字符串里的空格以及特殊字符,化腐朽为神奇的一步，例如string='1----2*-9+-3*---2+7/-+2'"""
        if len(re.findall("[\-\+]{2}", string)) or len(
                re.findall("[\*\/][\-\+]", string)):  # 只要出现两个运算符(至少有一个是+或-)连在一起的，就直接替换
            string = re.sub("([\-\+]{2,})", lambda x: "-" if x.group().count("-") % 2 == 1 else "+", string)
            string = re.sub(r"([\-\+]\d+[\*\/])([\-\+])(\d+\.*\d*)", lambda x: x.group(2) + x.group(1) + x.group(3),
                            string)  # 把类似-2*-23的字符串修改成--2*23
            return self.replace(string)
        else:
            return string

    def __npfunc(self, number_list, symbol_list):
        """接收['7', '3', '99','4', '2998']和['/', '*', '/', '*']，并进行计算"""
        value = float(number_list[0])
        for i, symbol in enumerate(symbol_list):  # 类似functools.reduce，这里需要迭代每个运算符对应的函数
            value = self.dict[symbol](value, float(number_list[i + 1]))
        return str(value)

    def loop(self, string):  # 递归计算括号，没有括号则直接调用计算函数
        if len(re.findall("\([^()]+\)", string)) > 0:
            string = self.cutString(string)
            return self.loop(string)
        else:
            string = self.replace(string)
            return self.calculate(string)

def main():
    calculate = Calculator()
    while True:
        string = str(input("\033[36;m请输入表达式 >>>\033[m "))
        string = string.replace(" ", "")
        try:
            outcome = calculate.loop(string)
            print(outcome)
        except:  # ValueError
            print("The expression isn't correct.")

if __name__ == '__main__':
    main()
