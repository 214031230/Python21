#!/usr/bin/env python3
userinfo = "../db/user_info"
schoolinfo = "../db/school_info"
classinfo = "../db/class_info"
couresinfo = "../db/coures_info"
teacherinfo  = "../db/teacher_info"
studentinfo = "../db/student_info"