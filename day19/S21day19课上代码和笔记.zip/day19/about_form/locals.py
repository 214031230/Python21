

def foo():
    name = "alex"
    age = 38
    print(locals())


foo()
