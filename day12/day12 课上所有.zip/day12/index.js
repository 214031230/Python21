var a  = 2;
console.log(a);
alert(a);