"""
跟用户相关的视图都写在这里
"""

from django.shortcuts import render, redirect, HttpResponse
from rbac.models import UserInfo
from django.conf import settings


def login(request):
    error_msg = ""
    if request.method == "POST":
        # 取数据
        username = request.POST.get("username")
        pwd = request.POST.get("password")
        # 校验
        user_obj = UserInfo.objects.filter(username=username, password=pwd).first()
        if user_obj:
            # 登陆成功
            # 拿到当前用户都有哪些权限
            # user_obj.roles.all()  # 拿到当前用户的所有角色
            ret = user_obj.roles.all().values("permissions__url").distinct()  # 取到去重之后的权限
            print(ret, type(ret))
            # 将用户的权限列表信息，存到session中
            request.session[settings.PERMISSION_SESSION_KEY] = list(ret)
            # 后续访问其他页面的时候，要判断访问的url在不在权限列表里
            return redirect("/customer/list/")
        else:
            # 登录失败
            error_msg = "用户名或密码错误"

    return render(request, "login.html", {"error_msg": error_msg})
