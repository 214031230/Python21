from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.


class UserInfo(AbstractUser):
    phone = models.CharField(max_length=11)
    avatar = models.FileField(upload_to="avatars/", default="avatars/default.png")


# 我自己去数据库创建一条用户数据
# UserInfo.objects.create(password="ooxx")
#
# # 调用auth内置的create_user方法创建用户，它会帮我做密码的加密处理
# UserInfo.objects.create_user(password="ooxx")
