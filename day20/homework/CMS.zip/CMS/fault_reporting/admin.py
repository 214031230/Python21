from django.contrib import admin
from fault_reporting import models
# Register your models here.

# admin.site.register(models.UserInfo)