from django.apps import AppConfig


class FaultReportingConfig(AppConfig):
    name = 'fault_reporting'
