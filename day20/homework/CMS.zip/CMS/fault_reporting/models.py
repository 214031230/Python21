from django.db import models
from django.contrib.auth.models import  AbstractUser

# Create your models here.


# class UserInfo(AbstractUser):
#     """
#     用户表，新增手机号字段
#     """
#     phone = models.CharField(max_length=11, verbose_name="手机号")
# 
#     class Meta:
#         verbose_name = "用户"
#         verbose_name_plural = verbose_name


