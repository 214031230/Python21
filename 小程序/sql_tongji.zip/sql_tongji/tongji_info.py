#!/usr/bin/env python3
import os
from concurrent.futures import ThreadPoolExecutor
school_list = "./school_list"
error_file = "./ip_error_list"
sql_file = "./sql"
def sql(school_name, school_ip):
    with open(sql_file, encoding="utf-8") as f:
        sql_cmd = f.read()
        sql_cmd.replace("北京研发", school_name)
    cmd = """
    mysql -uedu_platform -pedu_platform  -h%s  --database edu_platform -e"%s" >%s_%s.xls
    """ % (school_ip,sql_cmd, school_name, school_ip)

    check_network = """ ssh root@%s -p8997  -o ConnectTimeout=3  "w" """ % school_ip
    ret = os.popen(check_network).read()
    if ret:
        os.system(cmd)
    else:
        with open(error_file,mode="a",encoding="utf-8") as f:
            f.write("ERROR:%s 网络不可达" % school_ip)
        print("ERROR:%s 网络不可达" % school_ip)


if __name__ == '__main__':
    t = ThreadPoolExecutor(20)
    with open(school_list, encoding="utf-8") as f:
        for i in f:
            if i:
                school_name, school_ip = i.split()
                t.submit(sql,school_name,school_ip)
    t.shutdown()
    print("INFO:统计完毕")

# cmd = """mysql -uedu_platform -pedu_platform  -h58.116.247.250  --database edu_platform -e"
# UPDATE ks_question_base kqb
# INNER JOIN base_user bu ON bu.business_key = kqb.create_user_id SET kqb.level = 'SCHOOL'
# WHERE kqb.audit_status = 'APPROVED' AND kqb.level = 'PERSONAL' AND bu.category = 'teacher' AND bu.user_code IN ('05004722','05004735','12039775','05043739','06014662','05043744','05041474','05030312','05043741','05046714');"
# """
# os.system(cmd)
