#!/usr/bin/env python3
import re
a = "北京市陈经纶中学分校(小学部)"
b = re.sub("[()]", "", a)
print(b)