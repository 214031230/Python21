from django.shortcuts import render,redirect
from django.urls import reverse
from crm import models

def depart_list(request):
    """
    部门列表
    :param request:
    :return:
    """
    queryset = models.Department.objects.all()
    return render(request,'depart_list.html',{'queryset':queryset})


def depart_add(request):
    """
    部门添加
    :param request:
    :return:
    """
    if request.method == 'POST':
        title = request.POST.get('title')
        models.Department.objects.create(title=title)
        # return redirect('/depart/list/')
        return redirect(reverse('depart_list'))
    
    return render(request,'depart_add.html')