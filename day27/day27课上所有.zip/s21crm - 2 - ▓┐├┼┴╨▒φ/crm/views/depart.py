from django.shortcuts import render
from crm import models

def depart_list(request):
    """
    部门列表
    :param request:
    :return:
    """
    queryset = models.Department.objects.all()
    return render(request,'depart_list.html',{'queryset':queryset})