S21day27 crm系统

今日内容：
	1.Crm业务开发
		①部门管理
		②用户管理
		③校区、课程管理
		④客户管理
		⑤学院管理
	2.权限系统应用


任务：
	1. 创建项目
	2. 部门管理（ModelForm）
		- 部门列表
		- 添加
		- 编辑
		- 删除
	3. 用户管理
		- 用户列表 
			- choice选项
			- FK
			- M2M
		- 用户添加 
			- form对象循环，无需再进行每个字段的编写。
			- 页面form-control样式，重写__init__方法，动态为每个字段进行设置。
			- 本地化，form默认的英文错误提示信息转换成中文。
			- 密码的md5加密（ModelForm的钩子函数）
				
				class UserModelForm(forms.ModelForm):
					class Meta:
						model = models.UserInfo
						fields = "__all__"
					
					def __init__(self, *args, **kwargs):
						# 在父类的初始化方法中将7个字段当成字典放到了 self.fields 中。
						super(UserModelForm, self).__init__(*args, **kwargs)
						
						for key, field in self.fields.items():
							field.widget.attrs['class'] = 'form-control'
					
					def clean_password(self):
						"""
						密码对应的钩子方法
						:return:
						"""
						user_input_pwd = self.cleaned_data['password']
						return md5(user_input_pwd)
		- 用户编辑和用户删除
		
	4. 校区、课程、班级管理 
		
	5. 客户管理 
		- 公户管理
		- 私户管理
		
	6. 跟进记录
		
		
	7. 权限的应用
		参考使用文档：readme
		
	
总结：
	1. 学会开发技能（通用）
	2. 使用rbac组件（通用）
	
	以后公司项目开发：
		- 对rbac相关表：
			- 菜单
			- 权限
			- 角色 （权限角色关系）
		
		- 目前：权限信息的录入和分配（基于admin来做）
		
		- 权限信息录入不完整（录完）
		
		
我的感想：
	
		

作业：权限表中的增删改查（ModelForm实现）
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		